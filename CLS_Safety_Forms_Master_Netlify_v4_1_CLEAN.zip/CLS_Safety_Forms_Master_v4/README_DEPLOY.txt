CLS CRANES — SAFETY & OPERATIONS PORTAL v4

DEPLOY NOW
1. In Netlify, deploy this folder/ZIP to the existing cls-field-safety-forms project, or connect the folder to GitHub and let Netlify build it.
2. Netlify installs package dependencies and deploys the server function automatically.
3. Completed submissions are stored centrally in Netlify Blobs under the store: cls-safety-submissions.

EMAIL PDF DELIVERY
Central submission storage works without an email API key.
To also email completed PDFs, add these Netlify environment variables:
- RESEND_API_KEY
- FORM_FROM_EMAIL
- SUBMISSION_EMAIL (optional; defaults to ky@kylarity.com.au in this build)

IMPORTANT
Email is treated as delivery/notification, not the sole record store. A submission is stored centrally before any email attempt.
Offline submissions remain on the submitting device until connectivity returns, then the portal retries them.

VERSION
v4.0 — 29 August 2026
